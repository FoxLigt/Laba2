#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

const int Size_Array = 10; // Dimension of the array 

// Declaring a recursive function to search for the maximum element of the array
int Max_Element(int arr[], int start, int end)
{
    if (start == end)
    {
        return arr[start];
    } else
    {
        int mid = (start + end) / 2;
        int max1 = Max_Element(arr, start, mid); // recursive call for the first half of the array
        int max2 = Max_Element(arr, mid + 1, end); // recursive call for the second half of the array
        return max(max1, max2); // we return the maximum of the two values received 
    }
}
int main()
{
    int arr[Size_Array];
    // Filling an array with random numbers 
    srand(time(nullptr));
    for (int i = 0; i < Size_Array; i++)
    {
        arr[i] = rand() % 101;
    }
    // Output of the original array 
    cout << "Исходный массив: ";
    cout << "[ ";
    for (int i = 0; i < Size_Array; i++)
    {
        cout << arr[i] << " ";
    }
    cout << "]";
    cout << endl;
    // Calling a recursive function to find the maximum element of an array
    int maxValue = Max_Element(arr, 0, Size_Array - 1);
    // Search for the element number with the maximum value 
    int maxIndex = 0;
    for (int i = 0; i < Size_Array; i++) 
    {
        if (arr[i] == maxValue) 
        {
            maxIndex = i;
            break;
        }
    }
    // Output of the result
    cout << "Максимальный элемент массива: " << maxValue << endl;
    cout << "Индекс максимального элемента массива: " << maxIndex << endl;
}